﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banco {
    public class Conta {

        public int numero;
        public string titular;
        public double saldo;

        public bool Saca(double valor) {
            if (this.saldo >= valor) {
                this.saldo -= valor;
                return true;
            } else {
                return false;
            }
        }

        public void Transfere(Conta origem, double valor, Conta destino) {
            if (origem.Saca(valor)) {
                destino.Deposita(valor);
            }
        }
        public void Deposita(double valor) {

            this.saldo += valor;

        }
    }
}
