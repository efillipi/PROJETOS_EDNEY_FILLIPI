﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banco {
    public partial class Form4 : Form {


        public static double propriedade1{get;set;}
        public static double propriedade2 { get; set; }
        public Form4() {
            InitializeComponent();
        }
        public  void Recebevalor() {
            
            label2.Text = propriedade1.ToString();
            label3.Text = propriedade2.ToString();
            this.ShowDialog();
        }

        private void Form4_Load(object sender, EventArgs e) {

            

        }

        private void button1_Click(object sender, EventArgs e) {
            this.Close();
        }
    }
}
