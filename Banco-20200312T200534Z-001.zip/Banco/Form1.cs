﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banco {
    public partial class Form1 : Form {

        Conta c1 = new Conta();
        Conta c2 = new Conta();
        Conta auxiliar = new Conta();
        Conta auxiliar2 = new Conta();
        Form2 pegavalor = new Form2();
        Form3 pegavalor3 = new Form3();
        Form4 saldocontas = new Form4();
        public Form1() {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) {

            auxiliar = pegavalor.pegarValores();
            int numero = auxiliar.numero;
            double valor = auxiliar.saldo;

            if (numero == 1) {
                c1.Deposita(valor);
            } else
            if (numero == 2) {
                c2.Deposita(valor);
            } else {

                MessageBox.Show("CONTA INVALIDA");
            }

        }

        private void button4_Click(object sender, EventArgs e) {
            
            Form4.propriedade1 = c1.saldo;
            Form4.propriedade2 = c2.saldo;
            saldocontas.Recebevalor();


        }

        private void button2_Click(object sender, EventArgs e) {

            auxiliar = pegavalor.pegarValores();
            int numero = auxiliar.numero;
            double valor = auxiliar.saldo;

            if (numero == 1) {
                c1.Saca(valor);
            } else
            if (numero == 2) {
                c2.Saca(valor);
            } else {

                MessageBox.Show("CONTA INVALIDA");
            }
        }

        private void button3_Click(object sender, EventArgs e) {

            auxiliar = pegavalor3.pegarValores();
            auxiliar2 = pegavalor3.pegarValores2();
            int numero = auxiliar.numero;
            int numero2 = auxiliar2.numero;
            double valor = auxiliar.saldo;

            if(numero == 1 && numero2 == 2)
            {
                c1.Transfere(c1, valor, c2);
            }
            else
            if (numero == 2 && numero2 == 1) {
                c2.Transfere(c2, valor, c1);
            } else {
                MessageBox.Show("CONTAS INVALIDAS");
            }
        }
    }
}
