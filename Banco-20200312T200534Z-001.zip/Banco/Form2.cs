﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banco {
    public partial class Form2 : Form {
        public Form2() {
            InitializeComponent();

        }

        public Conta pegarValores() {
            Conta pegavalor = new Conta();
            this.ShowDialog();
            pegavalor.numero = int.Parse(textBox1.Text);
            pegavalor.saldo = int.Parse(textBox2.Text);
            return pegavalor;
        }

        private void button1_Click(object sender, EventArgs e) {
            this.Close();
        }
    }
}
